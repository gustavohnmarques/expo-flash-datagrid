# react-native-flash-datagrid

High-performance mobile data grid for React Native, inspired by `@mui/x-data-grid` patterns and built on top of `@shopify/flash-list`.

## Features

- Fixed header and footer
- Vertical virtualization with FlashList
- Unified horizontal scroll for header/body/footer
- Client and server modes
- Sorting, filtering, global search, pagination, infinite loading
- Column visibility menu (hide/show/reset)
- Selection model with mobile-first long-press behavior
- Typed API with TypeScript generics
- Pure engine functions with unit tests

## Installation

```sh
npm install react-native-flash-datagrid @shopify/flash-list
```

or

```sh
yarn add react-native-flash-datagrid @shopify/flash-list
```

## Quick Start

```tsx
import { DataGrid, type ColumnDef } from 'react-native-flash-datagrid';

type User = {
  id: string;
  name: string;
  age: number;
  active: boolean;
};

const columns: ColumnDef<User>[] = [
  { field: 'name', headerName: 'Name', searchable: true, flex: 1 },
  { field: 'age', headerName: 'Age', type: 'number', width: 90 },
  { field: 'active', headerName: 'Active', type: 'boolean', width: 90 },
];

<DataGrid<User>
  mode="client"
  rows={rows}
  columns={columns}
  state={queryState}
  onStateChange={setQueryState}
  style={{ flex: 1 }}
/>;
```

## Client Mode Example

```tsx
<DataGrid<User>
  mode="client"
  rows={rows}
  columns={columns}
  state={state}
  onStateChange={setState}
  enableMultiSort
  searchDebounceMs={300}
  pageSizeOptions={[10, 25, 50]}
/>
```

In client mode, the grid applies:

1. filter
2. search
3. sort
4. pagination

locally on `rows`.

## Server Mode Example

```tsx
<DataGrid<User>
  mode="server"
  rows={serverRows}
  rowCount={serverTotal}
  columns={columns}
  state={serverState}
  onStateChange={setServerState}
  loading={loading}
/>
```

In server mode, the grid **does not** process rows locally for sorting/filter/search.
Use `onStateChange` (or specific callbacks) to request new rows from your API.

## Empty State Text

Use `emptyLabel` for a direct override. If you already centralize translations in
`localeText`, you can keep using `localeText.emptyLabel`.

```tsx
<DataGrid<User>
  mode="client"
  rows={rows}
  columns={columns}
  emptyLabel="Nenhum resultado para os filtros atuais"
/>
```

```tsx
<DataGrid<User>
  mode="client"
  rows={rows}
  columns={columns}
  localeText={{
    emptyLabel: 'Nenhum cliente encontrado',
  }}
/>
```

## Column Definition

`ColumnDef<TRow>` supports:

- `field`, `headerName`
- `width`, `minWidth`, `flex`
- `type`: `'string' | 'number' | 'date' | 'datetime' | 'boolean' | 'actions' | 'custom'`
- `sortable`, `filterable`, `hideable`, `searchable`
- `valueGetter`, `valueFormatter`
- `renderCell`, `renderHeader`
- `sortComparator`, `filterOperators`
- `align`, `headerAlign`
- `actions`, `actionTrigger`

## Custom Filters

You can override operators globally by type or by field:

```tsx
<DataGrid<User>
  mode="client"
  rows={rows}
  columns={columns}
  filterOperatorsByType={{
    string: [
      {
        value: 'startsWithUpper',
        label: 'Starts with upper',
        apply: ({ cellValue, filterValue }) =>
          String(cellValue ?? '').startsWith(
            String(filterValue ?? '').toUpperCase()
          ),
      },
    ],
  }}
/>
```

Built-in operators include string, number, date/datetime, and boolean defaults.

## Row Action Icons

Long-press row actions accept `icon` either as a ready `ReactNode` or as a
function that receives the recommended `color` and `size` for the menu item.

```tsx
import { MaterialIcons } from '@expo/vector-icons';

const rowActions = [
  {
    key: 'checkout',
    label: 'Checkout',
    icon: ({ color, size }) => (
      <MaterialIcons name="shopping-cart" color={color} size={size} />
    ),
    onPress: ({ rowId }) => {
      console.log(rowId);
    },
  },
];
```

## Actions Column

You can create a native actions column and reuse the same action items shape from
`rowActions`.

- If the resolved action list has 1 or more items, the grid opens the popup menu.
- Popup items can render with icon only or icon + label.
- The actions cell trigger can also render icon only or icon + label.

```tsx
import { MaterialIcons } from '@expo/vector-icons';

const columns: ColumnDef<User>[] = [
  {
    field: 'actions',
    headerName: 'Actions',
    type: 'actions',
    width: 132,
    actions: ({ row, rowId, position }) => [
      {
        key: `checkout-${rowId}`,
        label: 'Checkout',
        icon: ({ color, size }) => (
          <MaterialIcons name="shopping-cart" color={color} size={size} />
        ),
        onPress: () => {
          console.log(row.id, position.pageX);
        },
      },
      {
        key: `medical-${rowId}`,
        label: 'Run ER',
        icon: ({ color, size }) => (
          <MaterialIcons name="medical-services" color={color} size={size} />
        ),
        onPress: () => {
          console.log(row.id);
        },
      },
    ],
    actionTrigger: {
      display: 'both',
      label: 'Actions',
      icon: ({ color, size }) => (
        <MaterialIcons name="more-horiz" color={color} size={size} />
      ),
    },
  },
];
```

## Performance Notes

- `keyExtractor` is always required and used
- FlashList receives `estimatedItemSize` via internal override props
- Row/cell/header components are memoized
- Avoid storing local mutable state inside row/cell renderers
- Prefer stable `rows`, `columns`, and callbacks (`useMemo`/`useCallback`)

## Main API (DataGrid Props)

- Data: `rows`, `columns`, `getRowId`
- Rendering: `rowHeight`, `estimatedItemSize`, `zebraRows`, `getRowStyle`
- Models:
  - `sortModel`, `filterModel`, `searchText`
  - `columnVisibilityModel`, `paginationModel`, `selectionModel`
- Unified state channel:
  - `state?: Partial<QueryState>`
  - `initialState?: Partial<QueryState>`
  - `onStateChange?: (next: QueryState) => void`
  - `onQueryChange?: (next: QueryState) => void`
- Pagination/infinite: `rowCount`, `pageSizeOptions`, `infinite`, `onEndReached`
- Events: `onRowPress`, `onRowLongPress`, `onCellPress`, `onCellLongPress`
- UI: `theme`, `locale`, `localeText`, `emptyLabel`, `emptyState`, `loadingOverlay`

## Engine Utilities

Exported pure functions:

- `applySorting(rows, columns, sortModel)`
- `applyFilter(rows, columns, filterModel)`
- `applySearch(rows, columns, searchText)`
- `paginateRows(rows, paginationModel)`
- `applyClientPipeline(...)`

These are unit-tested and can be reused in adapters, API layers, or custom hooks.

## Expo Notes

- Example app uses Expo managed workflow and starts with:

```sh
cd example
npx expo start
```

- `example/metro.config.js` uses `@expo/metro-config`
- Workspace Metro setup watches the library root and resolves shared `node_modules`
- This avoids duplicated React instances in local development

## Local Build

If you want to rebuild the library and install it in another local project before publishing, see:

- [docs/BUILD_AND_USE_LOCALLY.md](./docs/BUILD_AND_USE_LOCALLY.md)

## Known Pitfalls

- If rows are recreated on every render, virtualization benefits are reduced
- For controlled mode, keep `state` updates immutable and stable
- If `searchable` is not enabled on any column, global search returns no matches
- In server mode, you must fetch and pass processed rows yourself

## Example App

The `example/` app contains `DataGridDemo` with:

- 10k client rows
- simulated server mode with delay
- filtering by string/number/date/boolean columns
- column visibility modal
- selection + press/long-press events
- row color customization by status

## License

MIT
