import type { ColumnDef, ColumnType, FilterModel, FilterOperator, FilterOperatorsConfig } from '../types';
export declare function getDefaultFilterOperatorsByType<TRow = unknown>(): Record<ColumnType, FilterOperator<TRow>[]>;
export declare function applyFilter<TRow>(rows: TRow[], columns: ColumnDef<TRow>[], filterModel: FilterModel, options?: FilterOperatorsConfig<TRow>): TRow[];
//# sourceMappingURL=filtering.d.ts.map