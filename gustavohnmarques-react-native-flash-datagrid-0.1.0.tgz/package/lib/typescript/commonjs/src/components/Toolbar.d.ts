import React from 'react';
import type { DataGridLocaleText } from '../types';
interface ToolbarProps {
    backgroundColor: string;
    borderColor: string;
    textColor: string;
    localeText: DataGridLocaleText;
    hasActiveSearch: boolean;
    hasActiveFilters: boolean;
    selectionCount: number;
    title?: React.ReactNode;
    onOpenSearch: () => void;
    onOpenFilters: () => void;
    onOpenColumns: () => void;
    onClearSelection?: () => void;
}
export declare const Toolbar: React.NamedExoticComponent<ToolbarProps>;
export {};
//# sourceMappingURL=Toolbar.d.ts.map