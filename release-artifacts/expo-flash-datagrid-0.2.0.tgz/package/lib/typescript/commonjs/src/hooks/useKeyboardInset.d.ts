export declare function useKeyboardInset(enabled: boolean): number;
//# sourceMappingURL=useKeyboardInset.d.ts.map