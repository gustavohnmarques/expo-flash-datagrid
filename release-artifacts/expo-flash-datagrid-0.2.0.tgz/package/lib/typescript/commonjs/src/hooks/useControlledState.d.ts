export declare function useControlledState<T>(controlledValue: T | undefined, defaultValue: T): [T, (next: T | ((prev: T) => T)) => void, boolean];
//# sourceMappingURL=useControlledState.d.ts.map