import type { ColumnLayoutItem, ColumnVisibilityModel, DataGridProps } from '../types';
interface UseColumnLayoutParams<TRow> {
    columns: DataGridProps<TRow>['columns'];
    columnVisibilityModel: ColumnVisibilityModel;
    containerWidth: number;
}
interface UseColumnLayoutResult<TRow> {
    visibleColumns: ColumnLayoutItem<TRow>[];
    totalWidth: number;
}
export declare function useColumnLayout<TRow>({ columns, columnVisibilityModel, containerWidth, }: UseColumnLayoutParams<TRow>): UseColumnLayoutResult<TRow>;
export {};
//# sourceMappingURL=useColumnLayout.d.ts.map