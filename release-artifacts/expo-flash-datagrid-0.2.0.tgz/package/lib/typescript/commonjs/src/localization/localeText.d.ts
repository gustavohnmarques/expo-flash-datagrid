import type { DataGridLocale, DataGridLocaleText } from '../types';
export declare const EN_LOCALE_TEXT: DataGridLocaleText;
export declare const PT_LOCALE_TEXT: DataGridLocaleText;
export declare function resolveLocaleText(locale?: DataGridLocale, overrides?: Partial<DataGridLocaleText>): DataGridLocaleText;
export declare function formatLocale(template: string, values: Record<string, string | number>): string;
//# sourceMappingURL=localeText.d.ts.map