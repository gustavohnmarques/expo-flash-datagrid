import React from 'react';
import type { GridPressPosition, GridRowActionIcon } from '../types';
interface RowActionMenuItem {
    key: string;
    label?: string;
    icon?: GridRowActionIcon;
    disabled?: boolean;
    destructive?: boolean;
    onPress: () => void;
}
interface RowActionMenuProps {
    visible: boolean;
    anchor: GridPressPosition | null;
    items: RowActionMenuItem[];
    onClose: () => void;
}
export declare const RowActionMenu: React.NamedExoticComponent<RowActionMenuProps>;
export {};
//# sourceMappingURL=RowActionMenu.d.ts.map