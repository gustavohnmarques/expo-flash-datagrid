import type { GestureResponderEvent } from 'react-native';
import type { CellEventParams, ColumnLayoutItem } from '../types';
interface GridCellProps<TRow> {
    row: TRow;
    rowId: string;
    rowIndex: number;
    columnLayout: ColumnLayoutItem<TRow>;
    isSelected: boolean;
    textColor: string;
    dividerColor: string;
    cellPadding: number;
    onCellPress?: (params: CellEventParams<TRow>) => void;
    onCellLongPress?: (params: CellEventParams<TRow>, event: GestureResponderEvent) => void;
    onActionCellPress?: (row: TRow, rowId: string, column: ColumnLayoutItem<TRow>['column'], event: GestureResponderEvent) => void;
}
declare function GridCellComponent<TRow>({ row, rowId, rowIndex, columnLayout, isSelected, textColor, dividerColor, cellPadding, onCellPress, onCellLongPress, onActionCellPress, }: GridCellProps<TRow>): import("react/jsx-runtime").JSX.Element;
export declare const GridCell: typeof GridCellComponent;
export {};
//# sourceMappingURL=GridCell.d.ts.map