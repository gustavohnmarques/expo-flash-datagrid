import type { GestureResponderEvent } from 'react-native';
import type { ColumnLayoutItem } from '../types';
interface GridActionCellProps<TRow> {
    row: TRow;
    rowId: string;
    rowIndex: number;
    columnLayout: ColumnLayoutItem<TRow>;
    dividerColor: string;
    cellPadding: number;
    onPress: (row: TRow, rowId: string, event: GestureResponderEvent) => void;
}
declare function GridActionCellComponent<TRow>({ row, rowId, rowIndex: _rowIndex, columnLayout, dividerColor, cellPadding, onPress, }: GridActionCellProps<TRow>): import("react/jsx-runtime").JSX.Element;
export declare const GridActionCell: typeof GridActionCellComponent;
export {};
//# sourceMappingURL=GridActionCell.d.ts.map