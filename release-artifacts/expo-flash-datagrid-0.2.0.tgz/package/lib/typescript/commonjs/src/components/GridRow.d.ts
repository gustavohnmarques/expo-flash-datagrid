import type { GestureResponderEvent, StyleProp, ViewStyle } from 'react-native';
import type { ColumnDef, ColumnLayoutItem } from '../types';
interface GridRowProps<TRow> {
    row: TRow;
    rowId: string;
    rowIndex: number;
    columns: ColumnLayoutItem<TRow>[];
    rowHeight: number;
    rowBackground: string;
    rowAltBackground: string;
    rowTextColor: string;
    dividerColor: string;
    selectionBackground: string;
    zebraRows?: boolean;
    getRowStyle?: (row: TRow, index: number) => StyleProp<ViewStyle>;
    isSelected: boolean;
    isContextActive?: boolean;
    checkboxSelection?: boolean;
    onToggleSelection?: (rowId: string) => void;
    onRowPress?: (row: TRow, rowId: string) => void;
    onRowLongPress?: (row: TRow, rowId: string, event: GestureResponderEvent) => void;
    onCellPress?: (row: TRow, rowId: string, column: ColumnDef<TRow>) => void;
    onCellLongPress?: (row: TRow, rowId: string, column: ColumnDef<TRow>, event: GestureResponderEvent) => void;
    onActionCellPress?: (row: TRow, rowId: string, column: ColumnDef<TRow>, event: GestureResponderEvent) => void;
    cellPadding: number;
}
declare function GridRowComponent<TRow>({ row, rowId, rowIndex, columns, rowHeight, rowBackground, rowAltBackground, rowTextColor, dividerColor, selectionBackground, zebraRows, getRowStyle, isSelected, isContextActive, checkboxSelection, onToggleSelection, onRowPress, onRowLongPress, onCellPress, onCellLongPress, onActionCellPress, cellPadding, }: GridRowProps<TRow>): import("react/jsx-runtime").JSX.Element;
export declare const GridRow: typeof GridRowComponent;
export {};
//# sourceMappingURL=GridRow.d.ts.map