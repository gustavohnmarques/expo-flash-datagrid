import type { ColumnLayoutItem, DataGridSortIcons, SortModel } from '../types';
interface GridHeaderProps<TRow> {
    columns: ColumnLayoutItem<TRow>[];
    sortModel: SortModel;
    onSortPress?: (field: string) => void;
    headerHeight: number;
    headerBackground: string;
    headerTextColor: string;
    borderColor: string;
    dividerColor: string;
    cellPadding: number;
    checkboxSelection?: boolean;
    sortIcons?: DataGridSortIcons;
    showUnsortedSortIcon?: boolean;
}
declare function GridHeaderComponent<TRow>({ columns, sortModel, onSortPress, headerHeight, headerBackground, headerTextColor, borderColor, dividerColor, cellPadding, checkboxSelection, sortIcons, showUnsortedSortIcon, }: GridHeaderProps<TRow>): import("react/jsx-runtime").JSX.Element;
export declare const GridHeader: typeof GridHeaderComponent;
export {};
//# sourceMappingURL=GridHeader.d.ts.map