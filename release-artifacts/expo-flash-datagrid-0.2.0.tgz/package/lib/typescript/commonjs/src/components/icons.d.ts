interface IconProps {
    color?: string;
    size?: number;
}
export declare function GridIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function FilterIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function DownloadIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function SearchIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function ChevronDownIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function ChevronUpIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function ChevronLeftIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function ChevronRightIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function TrashIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function PlusIcon({ color, size }: IconProps): import("react/jsx-runtime").JSX.Element;
export declare function MoreHorizontalIcon({ color, size, }: IconProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=icons.d.ts.map