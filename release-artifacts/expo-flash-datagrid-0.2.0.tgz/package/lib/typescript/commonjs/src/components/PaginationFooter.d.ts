import React from 'react';
import type { DataGridLocaleText, PaginationModel } from '../types';
interface PaginationFooterProps {
    paginationModel: PaginationModel;
    pageSizeOptions: number[];
    rowCount: number;
    rangePaginationModel?: PaginationModel;
    rangeRowCount?: number;
    footerHeight: number;
    footerBackground: string;
    borderColor: string;
    loading?: boolean;
    infinite?: boolean;
    localeText: DataGridLocaleText;
    onPaginationModelChange: (next: PaginationModel) => void;
}
export declare const PaginationFooter: React.NamedExoticComponent<PaginationFooterProps>;
export {};
//# sourceMappingURL=PaginationFooter.d.ts.map