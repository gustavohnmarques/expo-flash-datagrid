import type { ColumnDef, DataGridLocaleText, FilterModel, FilterOperatorsConfig } from '../types';
interface FilterPanelModalProps<TRow> extends FilterOperatorsConfig<TRow> {
    visible: boolean;
    columns: ColumnDef<TRow>[];
    model: FilterModel;
    localeText: DataGridLocaleText;
    maxFilters: number;
    onChange: (next: FilterModel) => void;
    onClose: () => void;
}
declare function FilterPanelModalComponent<TRow>({ visible, columns, model, localeText, maxFilters, onChange, onClose, filterOperatorsByType, filterOperatorsByField, }: FilterPanelModalProps<TRow>): import("react/jsx-runtime").JSX.Element | null;
export declare const FilterPanelModal: typeof FilterPanelModalComponent;
export {};
//# sourceMappingURL=FilterPanelModal.d.ts.map