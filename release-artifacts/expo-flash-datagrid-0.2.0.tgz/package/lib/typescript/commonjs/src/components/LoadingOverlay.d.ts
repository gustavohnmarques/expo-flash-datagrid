import React from 'react';
export declare const LoadingOverlay: React.NamedExoticComponent<object>;
//# sourceMappingURL=LoadingOverlay.d.ts.map