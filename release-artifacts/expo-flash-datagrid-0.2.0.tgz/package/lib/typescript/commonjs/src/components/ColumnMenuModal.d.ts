import type { ColumnDef, ColumnVisibilityModel, DataGridLocaleText } from '../types';
interface ColumnMenuModalProps<TRow> {
    visible: boolean;
    columns: ColumnDef<TRow>[];
    model: ColumnVisibilityModel;
    localeText: DataGridLocaleText;
    onChange: (next: ColumnVisibilityModel) => void;
    onClose: () => void;
}
declare function ColumnMenuModalComponent<TRow>({ visible, columns, model, localeText, onChange, onClose, }: ColumnMenuModalProps<TRow>): import("react/jsx-runtime").JSX.Element;
export declare const ColumnMenuModal: typeof ColumnMenuModalComponent;
export {};
//# sourceMappingURL=ColumnMenuModal.d.ts.map