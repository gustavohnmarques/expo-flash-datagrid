import React from 'react';
import type { DataGridLocaleText } from '../types';
interface SearchModalProps {
    visible: boolean;
    value: string;
    localeText: DataGridLocaleText;
    onChange: (next: string) => void;
    onApply: () => void;
    onClear: () => void;
    onClose: () => void;
}
export declare const SearchModal: React.NamedExoticComponent<SearchModalProps>;
export {};
//# sourceMappingURL=SearchModal.d.ts.map