import React from 'react';
interface EmptyStateProps {
    label?: string;
}
export declare const EmptyState: React.NamedExoticComponent<EmptyStateProps>;
export {};
//# sourceMappingURL=EmptyState.d.ts.map