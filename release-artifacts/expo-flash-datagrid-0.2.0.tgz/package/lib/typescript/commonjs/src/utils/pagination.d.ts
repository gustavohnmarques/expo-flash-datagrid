import type { ColumnDef, FilterModel, FilterOperatorsConfig, PaginationModel, SortModel } from '../types';
export interface PaginationRange {
    from: number;
    to: number;
    total: number;
}
export declare function paginateRows<TRow>(rows: TRow[], paginationModel: PaginationModel): TRow[];
export declare function getPaginationRange(total: number, paginationModel: PaginationModel): PaginationRange;
export interface ClientPipelineParams<TRow> extends FilterOperatorsConfig<TRow> {
    rows: TRow[];
    columns: ColumnDef<TRow>[];
    filterModel: FilterModel;
    searchText: string;
    sortModel: SortModel;
    paginationModel: PaginationModel;
}
export interface ClientPipelineResult<TRow> {
    filteredRows: TRow[];
    searchedRows: TRow[];
    sortedRows: TRow[];
    paginatedRows: TRow[];
}
export declare function applyClientPipeline<TRow>(params: ClientPipelineParams<TRow>): ClientPipelineResult<TRow>;
//# sourceMappingURL=pagination.d.ts.map