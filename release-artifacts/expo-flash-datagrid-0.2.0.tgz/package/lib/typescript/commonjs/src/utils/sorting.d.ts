import type { ColumnDef, SortModel } from '../types';
export declare function applySorting<TRow>(rows: TRow[], columns: ColumnDef<TRow>[], sortModel: SortModel): TRow[];
//# sourceMappingURL=sorting.d.ts.map