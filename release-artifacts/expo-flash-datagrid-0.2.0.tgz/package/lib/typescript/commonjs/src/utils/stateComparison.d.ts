import type { ColumnVisibilityModel, FilterModel, PaginationModel, QueryState, SortModel } from '../types';
export declare function arePaginationModelsEqual(left: PaginationModel, right: PaginationModel): boolean;
export declare function areSortModelsEqual(left: SortModel, right: SortModel): boolean;
export declare function areSelectionModelsEqual(left: QueryState['selectionModel'], right: QueryState['selectionModel']): boolean;
export declare function areColumnVisibilityModelsEqual(left: ColumnVisibilityModel, right: ColumnVisibilityModel): boolean;
export declare function areFilterModelsEqual(left: FilterModel, right: FilterModel): boolean;
export declare function areQueryStatesEqual(left: QueryState, right: QueryState): boolean;
//# sourceMappingURL=stateComparison.d.ts.map