import type { ColumnDef, GridRowActionItem, GridRowActionsSource, RowLongPressParams } from '../types';
export declare function isActionColumn<TRow>(column: ColumnDef<TRow>): boolean;
export declare function hasRowActionContent<TRow>(action: GridRowActionItem<TRow>): boolean;
export declare function resolveRowActionsSource<TRow>(source: GridRowActionsSource<TRow> | undefined, params: RowLongPressParams<TRow>): GridRowActionItem<TRow>[];
//# sourceMappingURL=rowActions.d.ts.map