import type { ColumnDef, FilterSelectOption } from '../types';
export declare function getCellValue<TRow>(row: TRow, column: ColumnDef<TRow>): unknown;
export declare function areColumnValuesEqual(left: unknown, right: unknown): boolean;
export declare function toValueArray(value: unknown): unknown[];
export declare function findFilterSelectOption(options: FilterSelectOption[] | undefined, value: unknown): FilterSelectOption | undefined;
export declare function createFilterSelectOptionLabelMap(options: FilterSelectOption[] | undefined): Map<string, string> | undefined;
export declare function resolveFilterOptionLabels(options: FilterSelectOption[] | undefined, value: unknown): string[];
//# sourceMappingURL=columnValues.d.ts.map