import type { ColumnDef } from '../types';
export declare function applySearch<TRow>(rows: TRow[], columns: ColumnDef<TRow>[], searchText: string): TRow[];
//# sourceMappingURL=searching.d.ts.map