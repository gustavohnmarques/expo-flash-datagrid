import type { PaginationModel } from '../types';
export interface FooterState {
    rangePaginationModel?: PaginationModel;
    rangeRowCount?: number;
}
interface ResolveFooterStateParams {
    paginationModel: PaginationModel;
    localRowCount: number;
    localSearchActive: boolean;
    infinite?: boolean;
}
export declare function resolveFooterState(params: ResolveFooterStateParams): FooterState;
export {};
//# sourceMappingURL=footerState.d.ts.map